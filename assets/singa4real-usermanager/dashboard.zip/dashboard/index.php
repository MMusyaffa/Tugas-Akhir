<?php
session_start();
error_reporting(0);
if(!isset($_SESSION["username"])){	
header("location: ../login.html");
exit;	
}
if ($_GET["action"] == 'logout')
      {
         session_unset();
         session_destroy();
         header("location: ../login.html");
         exit;
      }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?php echo $_SESSION["fullname"] ?>'s dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <style type="text/css">
body{
background:#fff;
    font-size: 15px;
}
#wrapper{
padding:90px 15px;
}
.navbar-expand-lg .navbar-nav.side-nav{
flex-direction: column;
}
.card{
margin-bottom: 15px;
 border-radius:0; 
 box-shadow: 0 3px 5px rgba(0,0,0,.1); 
 }
.header-top{
box-shadow: 0 3px 5px rgba(0,0,0,.1)
}
@media(min-width:992px) {
#wrapper{
margin-left: 200px;padding: 90px 15px 15px;
}
.navbar-nav.side-nav{
background: linear-gradient(rgba(0, 0, 0, .7), rgba(0, 0, 0, .9)), url(images/img1.jpeg);
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    box-shadow: 5px 7px 25px #999;
position:fixed;top:56px;
flex-direction: column!important;left:0;width:200px;overflow-y:auto;bottom:0;overflow-x:hidden;padding-bottom:40px
}
}
.nin:hover{
background-color: #f44336;
    border-radius: 7px;
    box-shadow: 0px 0px 2px #111;
    transition: all .3s;	
}
.theme{
background-color: #f44336;
    border-radius: 7px;
    box-shadow: 2px 5px 10px #111;
    transition: all .3s;
    color: #fff;	
}
.current {
    background-color: #f44336;
    border-radius: 7px;
    box-shadow: 2px 5px 10px #111;
    transition: all .3s;
}

    </style>

</head>
<body>
<div id="wrapper">
    <nav class="navbar header-top fixed-top navbar-expand-lg  navbar-dark bg-dark">
      <a class="navbar-brand" href="#">Dashboard</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText"
        aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarText">
	  
        <ul class="navbar-nav side-nav pr-2 pl-2">
           <div class="mt-5"></div>
		   <li class="nav-item">
              <a href="./" class="nav-link text-light p-3 mb-2 <?php echo empty($_GET["page_action"]) || $_GET["page_action"] == "home" ? "current" : "nin";?>"> <i class="fa fa-home text-light fa-lg mr-3" aria-hidden="true"></i> Home</a>
         </li>
		   <li class="nav-item">
              <a href="./?page_action=profile" class="nav-link text-light p-3 mb-2 <?php echo $_GET["page_action"] == "profile" ? "current" : "nin";?>"> <i class="fa fa-user text-light fa-lg mr-3" aria-hidden="true"></i> Profile</a>
         </li>
		  <li class="nav-item">
              <a href="./?page_action=edit-profile" class="nav-link text-light p-3 mb-2 <?php echo $_GET["page_action"] == "edit-profile" ? "current" : "nin";?>"> <i class="fa fa-edit text-light fa-lg mr-3" aria-hidden="true"></i>Update Profile</a>
         </li>
			<li class="nav-item">
              <a  href="./?action=logout" class="nav-link text-light p-3 mb-2 nin"> <i class="fa fa-power-off text-light fa-lg mr-3" aria-hidden="true"></i> Logout</a>
            </li>
			<li class="nav-item">
              <a  href="https://www.buymeacoffee.com/singa4real" target="_blank" class="nav-link text-light p-3 mb-2 nin"> <i class="fa fa-coffee text-light fa-lg mr-3" aria-hidden="true"></i> Support Me</a>
            </li>
        </ul>
        
      </div>
    </nav>
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
<?php if(isset($_GET["page_action"])){
	include "./pages/".htmlspecialchars($_GET["page_action"]).".php";
}else{
	include "./pages/index.php";
}?>
        </div>
      </div>
      
    </div>
  </div>

</body>
</html>
