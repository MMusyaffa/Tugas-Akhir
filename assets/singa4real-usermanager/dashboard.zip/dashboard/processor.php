<?php
session_start();
// Turn off error reporting
error_reporting(0);
$domain_name = @$_SERVER['SERVER_NAME'];
$signup_success_page = "./dashboard/";
$signup_error_page = "";
$login_success_page = "./dashboard/";
$login_error_page = "";
$reset_success_page = "";
$reset_error_page = "";
$error_message = "";
// Includs database connection
include "db_connect.php";
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_name']) && $_POST['form_name'] == 'signupform')
{	
   
   $newusername = @$_POST['username'];
   $newemail = @$_POST['email'];
   $newpassword = @$_POST['password'];
   $confirmpassword = @$_POST['confirmpassword'];
   $newfullname = @$_POST['fullname'];
   $newgender = @$_POST['gender'];
   $newphone = @$_POST['phone'];
   $newstatus = "Active";
   $newtype = "User";
   $newexpire = "";
   if ($newpassword != $confirmpassword)
   {
      $error_message = 'Password and Confirm Password are not the same!<br>';
   }
   else
   if (isset($_POST['username']) && !preg_match("/^[A-Za-z0-9-_!@$]{1,50}$/", $newusername))
   {
	  $error_message .= 'Username is not valid, please check and try again!<br>';
   }
   else
   if (empty($_POST['password']) || !preg_match("/^[A-Za-z0-9-_!@$]{1,50}$/", $newpassword))
   {
      $error_message .= 'Password is not valid, please check and try again!<br>';
   }
   else
   if(isset($_POST['fullname']) && empty($_POST['fullname']) && !preg_match("/^[A-Za-z0-9-_!@$.' &]{1,50}$/", $newfullname))
   {
      $error_message .= 'Fullname is not valid, please check and try again!<br>';
   }
   else
   if (isset($_POST['email']) && empty($_POST['email']) && !preg_match("/^.+@.+\..+$/", $newemail))
   {
      $error_message .= 'Email is not a valid email address. Please check and try again!<br>';
   }
   else
   if (isset($_POST['phone']) && !preg_match("/^[0-9-_!@$]{1,50}$/", $_POST['phone']))
   {
      $error_message .= 'Invalid Phone number!<br>';
   }
   else
   if (isset($_POST['gender']) &&  empty($_POST['gender']))
   {
      $error_message .= 'Gender Is Needed!<br>';
   }
   if(isset($_POST['username']) && isset($_POST['email'])){
   $checkuser = SQLite3::escapeString ($newusername); // Escape value to protect against sql injection attack 
   $checkemail2 = SQLite3::escapeString ($newemail); // Escape value to protect against sql injection attack 
// Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE username='".$checkuser."' OR  email='".$checkemail2."' LIMIT 1";
   }else
   if(isset($_POST['username']) && !isset($_POST['email'])){
	   $checkuser = SQLite3::escapeString ($newusername); // Escape value to protect against sql injection attack 
// Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE username='".$checkuser."' LIMIT 1";   
   }elseif(isset($_POST['email']) && !isset($_POST['username'])){
   $checkemail2 = SQLite3::escapeString ($newemail); // Escape value to protect against sql injection attack 
// Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE email='".$checkemail2."' LIMIT 1";    
   }
   
$result = $db->query($query) or die($db->lastErrorMsg());
$match_row = $result->fetchArray(); // set the row in $data
   if (!empty($match_row["id"]))
     {
         $error_message .= 'Account already exist.<br>';
         
     }
	 
   if (empty($error_message))
   {
$npass = md5($newpassword);
	// Makes query with post data
	$query = "INSERT INTO users (username, password, email, fullname, phone, gender, status, type, expired) VALUES ('$newusername', '$npass', '$newemail', '$newfullname', '$newphone', '$newgender', '$newstatus', '$newtype', '$newexpire')";
	
	if( $db->exec($query) or die($db->lastErrorMsg()) ){
	  $_SESSION['username'] = $newusername;
      $_SESSION['fullname'] = $newfullname;
      $_SESSION['email'] = $newemail;
	  $_SESSION['type'] = "User";
	  $_SESSION['status'] = "Active";
	  $arr =  array("stat" =>"success", "returned" => $signup_success_page);
	  $db->close();
	  echo json_encode($arr);
      exit;
	}else{
		$arr = array("stat" => "fail", "returned" => "Sorry your account was not created, please try again later.");
		$db->close();
	   echo json_encode($arr);
	   exit;
	}
	  
      
   }else{
	   $arr = array("stat" => "fail", "returned" => $error_message);
	   $db->close();
	   echo json_encode($arr);
	   exit;
   }
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_name']) && $_POST['form_name'] == 'loginform')
{
   
   $success_page = $login_success_page;
   $error_page = $login_error_page;
   $crypt_pass = md5($_POST['password']);
   if(isset($_POST['username'])){
   $logintype = $_POST['username'];
    $loginuser = SQLite3::escapeString(@$logintype); // Escape value to protect against sql injection attack 
	$loginpassword = SQLite3::escapeString(@$crypt_pass); // Escape value to protect against sql injection attack 
   // Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE username='".$loginuser."' AND password = '".$loginpassword."' LIMIT 1";
   }else{
	$logintype = $_POST['email']; 
	    $loginuser = SQLite3::escapeString(@$logintype); // Escape value to protect against sql injection attack 
	$loginpassword = SQLite3::escapeString(@$crypt_pass); // Escape value to protect against sql injection attack 
   // Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE email='".$loginuser."' AND password = '".$loginpassword."' LIMIT 1";
   }
   $found = false;
   $fullname = '';
   $session_timeout = 600; 
$result = $db->query($query) or die($db->lastErrorMsg());
$match_row = $result->fetchArray(); // set the row in $data
   if(empty($match_row["id"]))
   {
      $arr = array("stat" => "fail", "returned" => "Account Not Found");
	  $db->close();
	   echo json_encode($arr);
	   exit;
   }
   else
   {
      if (session_id() == "")
      {
         session_start();
      }
      $_SESSION['username'] = $match_row["username"];
      $_SESSION['fullname'] = $match_row["fullname"];
      $_SESSION['email'] = $match_row["email"];
	  $_SESSION['type'] = $match_row["type"];
	  $_SESSION['status'] = $match_row["status"];
      $rememberme = isset($_POST['rememberme']) ? true : false;
      if ($rememberme)
      {
         setcookie('username', $loginuser, time() + 3600*24*30);
         setcookie('password', $loginpassword, time() + 3600*24*30);
      }
	  $arr =  array("stat" =>"success", "returned" => $login_success_page);
	  $db->close();
	  echo json_encode($arr);
      exit;
   }
$username = isset($_COOKIE['username']) ? $_COOKIE['username'] : '';
$password = isset($_COOKIE['password']) ? $_COOKIE['password'] : '';
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_name']) && $_POST['form_name'] == 'forgotpassword')
{
   $success_page = $reset_success_page;
   $error_page = $reset_error_page;
if(isset($_POST['username'])){
   $logintype = $_POST['username'];
    $loginuser = SQLite3::escapeString(@$logintype); // Escape value to protect against sql injection attack 
   // Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE username='".$loginuser."'  LIMIT 1";
   }else{
	$logintype = $_POST['email']; 
	$loginuser = SQLite3::escapeString(@$logintype); // Escape value to protect against sql injection attack 
   // Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE email='".$loginuser."' LIMIT 1";
   }
   
$result = $db->query($query);
$match_row = $result->fetchArray(); // set the row in $data
   if (!empty($match_row["id"]))
   {
      $newpassword = '';
      $alphanum = array('a','b','c','d','e','f','g','h','i','j','k','m','n','o','p','q','r','s','t','u','v','x','y','z','A','B','C','D','E','F','G','H','I','J','K','M','N','P','Q','R','S','T','U','V','W','X','Y','Z','2','3','4','5','6','7','8','9');
      $chars = sizeof($alphanum);
      $a = time();
      mt_srand($a);
      for ($i=0; $i < 6; $i++)
      {
         $randnum = intval(mt_rand(0,55));
         $newpassword .= $alphanum[$randnum];
      }
	 	  if(isset($_POST['username'])){ 
      $crypt_pass = md5($newpassword);
	  $usern = $match_row["username"];
	  // Makes query with post data
	$query = "UPDATE users set password='$crypt_pass' WHERE username='$usern'";
		  }else{
		$crypt_pass = md5($newpassword);
	  $usern = $match_row["email"];
	  // Makes query with post data
	$query = "UPDATE users set password='$crypt_pass' WHERE email='$usern'";	  
		  }
     if( $db->exec($query) ){ 
	  $mailto = $match_row["email"];
      $subject = 'New password';
      $message = 'Your new password for http://www.'.$domain_name.'/ is:';
      $message .= $newpassword;
      $header  = "From: account@".$domain_name.""."\r\n";
      $header .= "Reply-To: .account@".$domain_name.""."\r\n";
      $header .= "MIME-Version: 1.0"."\r\n";
      $header .= "Content-Type: text/plain; charset=utf-8"."\r\n";
      $header .= "Content-Transfer-Encoding: 8bit"."\r\n";
      $header .= "X-Mailer: PHP v".phpversion();
      mail($mailto, $subject, $message, $header);
	  $arr = array("stat" => "fail", "returned" => "A New password have been sent to your emaill address");
	  $db->close();
	   echo json_encode($arr);
	   exit;
	}else{
		$arr = array("stat" => "fail", "returned" => "Was Not able to process your request.");
		$db->close();
	   echo json_encode($arr);
	   exit;
	} 
      
   }
   else
   {
      $arr = array("stat" => "fail", "returned" => "Account Not Found");
	  $db->close();
	   echo json_encode($arr);
	   exit;
   }
   exit;
}
?>