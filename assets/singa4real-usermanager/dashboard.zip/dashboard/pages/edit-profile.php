<?php
session_start();
error_reporting(0);
if(!isset($_SESSION["username"])){
header("location: ../login.html");
exit;	
}
// Includs database connection
include "db_connect.php";
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{	
   
   $newusername = SQLite3::escapeString (@$_POST['username']);
   $newemail = SQLite3::escapeString(@$_POST['email']);
   $newpassword = SQLite3::escapeString(@$_POST['password']);
   $newfullname = SQLite3::escapeString(@$_POST['fullname']);
   $newgender = SQLite3::escapeString(@$_POST['gender']);
   $newphone = SQLite3::escapeString(@$_POST['phone']);

   if (empty($_POST['username']) && empty($_POST['email']))
   {
      $error_message = 'Atleast Email Or Username Field is needed for login!<br>';
   }
   else
   if (!empty($_POST['username']) && !preg_match("/^[A-Za-z0-9-_!@$]{1,50}$/", $newusername))
   {
	  $error_message .= 'Username is not valid!<br>';
   }
   else
   if (!empty($_POST['password']) && !preg_match("/^[A-Za-z0-9-_!@$]{1,50}$/", $newpassword))
   {
      $error_message .= 'Password is not valid!<br>';
   }
   else
   if(empty($_POST['fullname']) || !preg_match("/^[A-Za-z0-9 -_!@$]{1,50}$/", $newfullname))
   {
      $error_message .= 'Fullname is not valid!<br>';
   }
   else
   if (!empty($_POST['email']) && !preg_match("/^.+@.+\..+$/", $newemail))
   {
      $error_message .= 'Email is not a valid email!<br>';
   }
   else
   if (!empty($_POST['phone']) && !preg_match("/^[0-9-_!@$]{1,50}$/", $_POST['phone']))
   {
      $error_message .= 'Invalid Phone number!<br>';
   }
   else
   if (!empty($_POST['gender']) &&  !preg_match("/^[A-Za-z0-9-_!@$]{1,50}$/", $_POST['gender']))
   {
      $error_message .= 'Invalid Gender!<br>';
   }
if(!empty($_POST["email"]) && $_POST["email"] != $_SESSION["email"]){
// Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE email='".$newemail."' LIMIT 1"; 
$result = $db->query($query) or die($db->lastErrorMsg());
$match_row = $result->fetchArray(); // set the row in $data
   if (!empty($match_row["id"]))
     {
         $error_message .= 'Account with email already exist.<br>';
         
     }
}
 if(!empty($_POST["username"]) && $_POST["username"] != $_SESSION["username"]){
// Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE username='".$newusername."' LIMIT 1"; 
$result = $db->query($query) or die($db->lastErrorMsg());
$match_row = $result->fetchArray(); // set the row in $data
   if (!empty($match_row["id"]))
     {
         $error_message .= 'Account with username already exist.<br>';
         
     }
}  

	 
   if (empty($error_message))
   {
$loguser =  $_SESSION["username"];
$logemail =  $_SESSION["email"];   
   if(!empty($_POST['password'])){
   $npass = md5($newpassword); 
// Prepar the query to update the row data
if(!empty($loguser)){
	$query = "UPDATE users set username='$newusername', email='$newemail', fullname='$newfullname', gender='$newgender', phone='$newphone', password='$npass' WHERE username='$loguser'";	
}else{
$query = "UPDATE users set username='$newusername', email='$newemail', fullname='$newfullname', gender='$newgender', phone='$newphone', password='$npass' WHERE email='$logemail'";		
}

   }else{
// Prepar the query to update the row data
if(!empty($loguser)){
	$query = "UPDATE users set username='$newusername', email='$newemail', fullname='$newfullname', gender='$newgender', phone='$newphone' WHERE username='$loguser'";	
}else{
$query = "UPDATE users set username='$newusername', email='$newemail', fullname='$newfullname', gender='$newgender', phone='$newphone' WHERE email='$logemail'";		
} 
   }	   

	
	if( $db->exec($query) or die($db->lastErrorMsg()) ){
	  $_SESSION['username'] = $newusername;
      $_SESSION['fullname'] = $newfullname;
      $_SESSION['email'] = $newemail;
	  $_SESSION['type'] = "User";
	  $_SESSION['status'] = "Active";
	  $arr =  "<div class='bg-success text-white text-center'>Your profile have been updated Successfully.</div>";

	}else{
		$arr =  "<div class='bg-danger text-white text-center'>Sorry your profile was not updated, please try again later.</div>";

	}
	  
      
   }else{
	  $arr =  "<div class='bg-danger text-white text-center'>".$error_message."</div>"; 
   }
}
 if(!empty($_SESSION['username'])){
	   $checkuser = SQLite3::escapeString ($_SESSION['username']); // Escape value to protect against sql injection attack 
// Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE username='".$checkuser."' LIMIT 1";   
   }else{
   $checkemail2 = SQLite3::escapeString ($_SESSION['email']); // Escape value to protect against sql injection attack 
// Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE email='".$checkemail2."' LIMIT 1";    
   }
   
$result = $db->query($query) or die($db->lastErrorMsg());
$match_row = $result->fetchArray(); // set the row in $data
?>

<style type="text/css">


    </style>

<div class="border-bottom">
<h4>Update Profile</h4>
</div>
<div class="container">
    <div class="row ">
        <div class="col-lg-12 mx-auto">
            <div class="card mt-4 mx-auto p-4">
                <div class="card-body">
                    <div class="container">
                        <form id="update-form" role="form" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING']) ?>">
                            <div class="controls">
                                <div class="row">
								<div class="col-md-12"><?php echo @$arr;?></div>
                                    <div class="col-md-6">
                                        <div class="form-group"> <label for="form_name">Fullname *</label> <input id="form_name" type="text" name="fullname" class="form-control" placeholder="Please enter your fullname *" required="required" data-error="Fullname is required."  value="<?php echo @$match_row["fullname"];?>"> </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group"> <label for="form_need">Gender</label> <select id="form_need" name="gender" class="form-control" data-error="Please specify your need.">
                                                <option value=""  disabled>--Select Your Gender--</option>
                                                <option value="Male" <?php echo $match_row["gender"] == "Male" ? "selected" : "";?>>Male</option>
												<option value="Female" <?php echo $match_row["gender"] == "Female" ? "selected" : "";?>>Female</option>
                                                <option value="Others" <?php echo $match_row["gender"] == "Others" ? "selected" : "";?>>Others</option>
                                            </select> </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group"> <label for="form_email">Email</label> <input id="form_email" type="email" name="email" class="form-control" placeholder="Please enter your email"  data-error="Valid email is required" value="<?php echo @$match_row["email"];?>"> </div>
                                    </div>
									<div class="col-md-6">
                                        <div class="form-group"> <label for="form_phone">Phone No</label> <input id="form_phone" type="text" name="phone" class="form-control" placeholder="Please enter your phone number" value="<?php echo @$match_row["phone"];?>"> </div>
                                    </div>
                                    
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group"> <label for="form_email">Username</label> <input id="form_username" type="text" name="username" class="form-control" placeholder="Please enter Username "  data-error="Valid email is required" value="<?php echo @$match_row["username"];?>"> </div>
                                    </div>
									<div class="col-md-6">
                                        <div class="form-group"> <label for="form_phone">New Password</label> <input id="form_password" type="password" name="password" class="form-control" placeholder="Leave blank if don't want to update password"> </div>
                                    </div>
                                    <div class="col-md-12"> <input type="submit" class="btn theme btn-send pt-2" value="Update"> </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div> <!-- /.8 -->
        </div> <!-- /.row-->
    </div>
</div>
<?php
$db->close();
?>