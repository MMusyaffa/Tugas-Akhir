<?php
// Database name
$database_name = "users.db";
// Database Connection
$db = new SQLite3($database_name);
// Create Table "students" into Database if not exists 
$query = "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username STRING, email STRING, fullname STRING, phone STRING, gender STRING, password STRING, status STRING, expired STRING, type STRING)";
$db->exec($query);
?>